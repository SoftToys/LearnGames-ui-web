//(function ($, window, undefined) {  
export class Events{
     constructor(){
            this. onStart= "onStart";
             this.onStarting= "onStarting";
             this.onReceived= "onReceived";
             this.onError= "onError";
             this.onConnectionSlow= "onConnectionSlow";
             this.onReconnecting= "onReconnecting";
             this.onReconnect= "onReconnect";
             this.onStateChanged= "onStateChanged";
             this.onDisconnect= "onDisconnect";
     }
}