export class ConnectingMessageBuffer {

  constructor(connectionConfig, drainCallback) {
    this.buffer = [];
  }

  tryBuffer(message) {
    if (connectionConfig === ConnectionState.connecting) {
      buffer.push(message);

      return true;
    }

    return false;
  }

  drain() {
    // Ensure that the connection is connected when we drain (do not want to drain while a connection is not active)
    if (connectionConfig === $.ConnectionState.connected) {
      while (buffer.length > 0) {
        drainCallback(buffer.shift());
      }
    }
  }

  clear() {
    buffer = [];
  }
}
