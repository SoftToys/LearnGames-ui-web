export var Resources = {
  //static nojQuery() {return  "jQuery was not found. Please ensure jQuery is referenced before the SignalR client JavaScript file.";}
  nojQuery: "jQuery was not found. Please ensure jQuery is referenced before the SignalR client JavaScript file.",
  noTransportOnInit: "No transport could be initialized successfully. Try specifying a different transport or none at all for auto initialization.",
  errorOnNegotiate: "Error during negotiation request.",
  stoppedWhileLoading: "The connection was stopped during page load.",
  stoppedWhileNegotiating: "The connection was stopped during the negotiate request.",
  errorParsingNegotiateResponse: "Error parsing negotiate response.",
  errorDuringStartRequest: "Error during start request. Stopping the connection.",
  stoppedDuringStartRequest: "The connection was stopped during the start request.",
  errorParsingStartResponse: (resp)=> `Error parsing start response: '${resp}'. Stopping the connection.`,
  invalidStartResponse: (resp)=> `Invalid start response: '${resp}'. Stopping the connection.`,
  protocolIncompatible: (clientVer,serverVer)=> `You are using a version of the client that isn't compatible with the server. Client version ${clientVer}, server version ${serverVer}.`,
  sendFailed: "Send failed.",
  parseFailed: (resp)=> `Failed at parsing response: ${resp}`,
  longPollFailed: "Long polling request failed.",
  eventSourceFailedToConnect: "EventSource failed to connect.",
  eventSourceError: "Error raised by EventSource",
  webSocketClosed: "WebSocket closed.",
  pingServerFailedInvalidResponse:(server)=> `Invalid ping response when pinging server: '${server}'.`,
  pingServerFailed: "Failed to ping server.",
  pingServerFailedStatusCode: (code)=> `Failed to ping server.  Server responded with status code ${code}, stopping the connection.`,
  pingServerFailedParse: "Failed to parse ping server response, stopping the connection.",
  noConnectionTransport: "Connection is in an invalid state, there is no transport active.",
  webSocketsInvalidState: "The Web Socket transport is in an invalid state, transitioning into reconnecting.",
  reconnectTimeout: (timeout) => `Couldn't reconnect within the configured timeout of ${timeout} ms, disconnecting.`,
  reconnectWindowTimeout : (since,timeout)=>  `The client has been inactive since ${since} and it has exceeded the inactivity timeout of ${timeout} ms. Stopping the connection.`,
  negotiateAbortText: "__Negotiate Aborted__",
  defaultContentType: "application/x-www-form-urlencoded; charset=UTF-8"

};
export var ConnectionState = {
  connecting: 0,
  connected: 1,
  reconnecting: 2,
  disconnected: 4
};


//(function ($, window, undefined) {  
export var Events = {

  onStart: "onStart",
  onStarting: "onStarting",
  onReceived: "onReceived",
  onError: "onError",
  onConnectionSlow: "onConnectionSlow",
  onReconnecting: "onReconnecting",
  onReconnect: "onReconnect",
  onStateChanged: "onStateChanged",
  onDisconnect: "onDisconnect",

};
